// Import the functions you need from the SDKs you need
import { getFirestore } from "firebase/firestore";

import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBycaWvKw1zDA-AuaIV9pO7coiJA6cCIfk",
  authDomain: "blogging-app-ffe43.firebaseapp.com",
  projectId: "blogging-app-ffe43",
  storageBucket: "blogging-app-ffe43.appspot.com",
  messagingSenderId: "377464115985",
  appId: "1:377464115985:web:538a327a92b2c0190732b0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
 export const db = getFirestore(app);